package com.capstoneproject.myfogo.ui.item

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.capstoneproject.myfogo.R

class AddFogoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_fogo)
    }
}