MYFOGO is application aims to share leftover food and used items suitable for use to those in need.
